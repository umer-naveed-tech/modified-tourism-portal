<?php
/**
 * secrets.php — REAL credentials go here.
 * This file is listed in .gitignore and must NEVER be committed to Git.
 */

// ---- Database ----
define('DB_HOST', 'sql109.infinityfree.com');
define('DB_NAME', 'if0_42595234_tourism_db');
define('DB_USER', 'if0_42595234_tourism_db');
define('DB_PASS', 'Cpjb1122');

// ---- SMTP (Gmail) ----
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'umernaveed2580@gmail.com');       // ← YOUR GMAIL
define('SMTP_APP_PASSWORD', 'ocef fcqf crxa swvy');        // ← YOUR APP PASSWORD (16 digit)
define('SMTP_FROM_NAME', 'Ahmed Travels');

// ---- Admin ----
define('ADMIN_EMAIL', 'umernaveed2580@gmail.com');

// ---- AI Assistant (Groq — free) ----
define('GROQ_API_KEY', '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');

// ---- Google OAuth ----
define('GOOGLE_CLIENT_ID', '967103172146-3m0hlonrpkht8ht3it38d9a8smde6l9a.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'http://localhost/modified-tourism-portal/google_callback.php');
?>