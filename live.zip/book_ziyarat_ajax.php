<?php
session_start();
require_once 'config.php';

if(!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(!csrf_valid()) {
        echo json_encode(['success' => false, 'message' => 'Security check failed. Please refresh the page and try again.']);
        exit();
    }
    $type = $_POST['ziyarat_type'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $guests = $_POST['guests'] ?? 1;
    $pickup = $_POST['pickup_location'] ?? '';
    $requests = $_POST['special_requests'] ?? '';
    
    // Note: price is NOT trusted from the client anymore. These are the same
    // authoritative prices defined in services.php — keep both in sync if
    // Ziyarat pricing ever changes.
    $ziyarat_prices = [
        'makkah'  => 270,
        'madinah' => 270,
    ];

    if(!$type || !$date || !$pickup || !isset($ziyarat_prices[$type])) {
        echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
        exit();
    }

    $price = $ziyarat_prices[$type];
    
    $booking_no = 'ZIYARAT-' . date('Ymd') . '-' . rand(1000, 9999);
    $travel_datetime = $date . ($time ? ' at ' . $time : '');
    $from_location = $type == 'makkah' ? 'Makkah' : 'Madinah';
    $to_location = 'Ziyarat Sites';

    // 🔴 price_breakdown -- lets the agent panel show the ziyarat type,
    // pickup location, and any special requests, instead of just
    // "Ziyarat".
    $price_breakdown = json_encode([
        'ziyarat_type' => $type,
        'pickup_location' => $pickup,
        'special_requests' => $requests ?: null,
        'guests' => $guests,
        'travel_date' => $date,
        'travel_time' => $time ?: null,
    ]);
    
    $stmt = $pdo->prepare("INSERT INTO bookings (booking_no, user_id, service_type, service_id, booking_date, travel_date, from_location, to_location, guests, total_amount, price_breakdown, status, payment_status, can_cancel_until) VALUES (?, ?, 'ziyarat', 0, CURDATE(), ?, ?, ?, ?, ?, ?, 'pending', 'pending', DATE_ADD(NOW(), INTERVAL 1 HOUR))");
    
    if($stmt->execute([$booking_no, $_SESSION['user_id'], $travel_datetime, $from_location, $to_location, $guests, $price, $price_breakdown])) {
        echo json_encode(['success' => true, 'booking_no' => $booking_no, 'fare' => $price]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>