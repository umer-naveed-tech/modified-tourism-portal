<?php
// hotel_handlers/saja_hotel_makkah.php
//
// Saja Hotel Makkah -- 5 Star
// 3 room categories: Diplomatic Room, Executive Suite, Royal Suite.
// Diplomatic/Executive subtypes: Double/Triple/Quad. Royal Suite
// subtypes: Quad/Quint/6 Pax (alag set, DB se dynamically fetch hota
// hai jaisa Fairmont mein hai). NO weekday/weekend split (rate sheet
// mein sirf date-range based ek price hai). No extra bed, no
// supplement -- International/Far East menu sirf static info text.

require_once __DIR__ . '/base_handler.php';

class SajaHotelMakkahHandler implements HotelHandlerInterface {

    private $hotel_id = SAJA_HOTEL_ID;

    public function getRooms($hotel_id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT id, room_type, display_name, capacity, description FROM hotel_room_types WHERE hotel_id = ? ORDER BY id");
        $stmt->execute([$hotel_id]);
        $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rooms as &$room) {
            $room['has_seasonal'] = true;
            $room['price_label'] = 'Seasonal Pricing';
            $room['extra_bed_available'] = false;

            $bedStmt = $pdo->prepare("SELECT DISTINCT room_type FROM hotel_seasonal_pricing WHERE hotel_id = ? AND room_type_code = ? ORDER BY FIELD(room_type,'double','triple','quad','quint','sixpax')");
            $bedStmt->execute([$hotel_id, $room['room_type']]);
            $room['bed_types'] = $bedStmt->fetchAll(PDO::FETCH_COLUMN);
        }
        return $rooms;
    }

    public function getRoomDetails($room_id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM hotel_room_types WHERE id = ?");
        $stmt->execute([$room_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function calculatePrice($hotel_id, $room_type, $check_in, $check_out, $options = []) {
        global $pdo;
        $bed_type = $options['bed_type'] ?? '';
        if ($bed_type === '') return ['error' => 'Room selection incomplete'];

        $date_in = new DateTime($check_in);
        $date_out = new DateTime($check_out);
        $nights = $date_in->diff($date_out)->days;
        if ($nights < 1) return ['error' => 'Invalid dates'];

        $total = 0;
        $breakdown = [];

        for ($i = 0; $i < $nights; $i++) {
            $current_date = date('Y-m-d', strtotime($check_in . ' + ' . $i . ' days'));
            $is_weekend = $this->isWeekend($current_date) ? 1 : 0;
            $stmt = $pdo->prepare("SELECT * FROM hotel_seasonal_pricing WHERE hotel_id = ? AND room_type_code = ? AND room_type = ? AND is_weekend = ? AND ? BETWEEN start_date AND end_date");
            $stmt->execute([$hotel_id, $room_type, $bed_type, $is_weekend, $current_date]);
            $rule = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$rule) return ['error' => "No pricing available for date: $current_date"];
            $night_price = $rule['base_price_sar'] + $rule['markup_sar'];
            $total += $night_price;
            $breakdown[] = ['date' => $current_date, 'price' => $night_price, 'is_weekend' => $is_weekend,
                'rule_name' => date('d M Y', strtotime($rule['start_date'])) . ' - ' . date('d M Y', strtotime($rule['end_date']))];
        }

        return ['success' => true, 'room_total' => $total, 'grand_total' => $total, 'nights' => $nights, 'breakdown' => $breakdown];
    }

    public function validateBooking($data) {
        $errors = [];
        if (empty($data['check_in'])) $errors[] = 'Check-in date required';
        if (empty($data['check_out'])) $errors[] = 'Check-out date required';
        if (empty($data['room_id'])) $errors[] = 'Room selection required';
        return $errors;
    }

    public function getBookingOptions($hotel_id) {
        return ['extra_bed_available' => false, 'has_weekend_split' => false];
    }

    public function renderRoomSelection($hotel_id, $rooms) {
        ob_start();
        ?>
        <div style="margin-top:16px; background:rgba(16,185,129,0.04); padding:12px 16px; border-radius:8px; border:1px solid rgba(16,185,129,0.06); font-size:13px; color:#34d399;">
            🍽️ <strong>International Menu:</strong> Breakfast SAR 45 | Lunch SAR 60 | Dinner SAR 75 (per pax per day)<br>
            🍽️ <strong>Far East Menu:</strong> Full Board SAR 65 (per pax per day)
        </div>
        <?php
        return ob_get_clean();
    }

    private function isWeekend($date) {
        $day = date('N', strtotime($date));
        return ($day == 4 || $day == 5);
    }
}
?>