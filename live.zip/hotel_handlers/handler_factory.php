<?php
// hotel_handlers/handler_factory.php

// NAYE HOTELS KE IDs
define('FAIRMONT_HOTEL_ID', 145);
define('SWISSOTEL_HOTEL_ID', 146);
define('SWISSOTEL_ALMAQAM_HOTEL_ID', 147);
define('ALMARWA_HOTEL_ID', 148);
define('ALSAFWAH_HOTEL_ID', 149);
define('CONRAD_HOTEL_ID', 150);
define('HILTONSUITES_HOTEL_ID', 151);
define('HILTONCONVENTION_HOTEL_ID', 152);
define('DOUBLETREE_HOTEL_ID', 153);
define('ELAFKINDA_HOTEL_ID', 154);
define('SHERATON_HOTEL_ID', 157);
define('MHOTEL_HOTEL_ID', 158);
define('SAJA_HOTEL_ID', 159);
define('LEMERIDIEN_HOTEL_ID', 160);
define('GRANDALMASSAH_HOTEL_ID', 161);
define('ROYALMAJESTIC_HOTEL_ID', 162);
define('MAYSANMASHAER_HOTEL_ID', 163);
define('MAYSANMAQAM_HOTEL_ID', 164);
define('BADRALMASSAH_HOTEL_ID', 165);
define('RAMADAALFAYZEN_HOTEL_ID', 166);
define('EMAARGRAND_HOTEL_ID', 167);
define('SNOODAJYAD_HOTEL_ID', 168);
define('MHOTELALDANA_HOTEL_ID', 69);
define('EMAARALMANAR_HOTEL_ID', 83);
define('EMAARALANDALUSIA_HOTEL_ID', 84);
define('EMAARWORTHELITE_HOTEL_ID', 85);
define('EMAARALKHALIL_HOTEL_ID', 86);
define('MAKAREMAJYAD_HOTEL_ID', 67);
define('MANZELAJYAD_HOTEL_ID', 70);
define('ELAFBAKKAH_HOTEL_ID', 71);   // NAYA
define('ELAFQINWAN_HOTEL_ID', 76);   // NAYA

// MADINAH HOTELS (naya batch)
define('JAYDEN_HOTEL_ID', 169);       // NAYA -- Jayden Hotel Madinah
define('DARALTAQWA_HOTEL_ID', 94);    // NAYA -- Dar Al Taqwa Hotel Madinah (existing empty hotel row)
define('DARALIMAN_HOTEL_ID', 96);     // NAYA -- Dar Al Iman Intercontinental Madinah (existing empty hotel row)
define('DARALHIJRA_HOTEL_ID', 97);    // NAYA -- Dar Al Hijra Intercontinental Madinah (existing empty hotel row)
define('BILTMORE_HOTEL_ID', 93);      // NAYA -- The Biltmore Hotel Madinah (existing empty hotel row)
define('MAKAREMBURJ_HOTEL_ID', 106);  // NAYA -- Makarem Burj Al Madinah (existing empty hotel row)
define('MAKAREMHARAMVIEWSUITES_HOTEL_ID', 108); // NAYA -- Makarem Haram View Suites (existing empty hotel row)
define('ELAFTAQWA_HOTEL_ID', 91);     // NAYA -- Elaf Taqwa Hotel Madinah (existing empty hotel row)
define('CROWNPLAZA_HOTEL_ID', 99);         // NAYA -- Crown Plaza by IHG Madinah (existing empty hotel row)
define('MILLENIUMAQEEQ_HOTEL_ID', 101);    // NAYA -- Millenium Al Aqeeq Ex. Al Aqeeq Madinah (existing empty hotel row)
define('MILLENIUMTAIBAH_HOTEL_ID', 100);   // NAYA -- Millenium Al Taibah Hotel Madinah (existing empty hotel row)
define('NOVOTELMADINAH_HOTEL_ID', 170);    // NAYA -- Novotel Madinah
define('DARALEIMANHARAM_HOTEL_ID', 104);   // NAYA -- Dar Al Eiman Al Haram Hotel Madinah (existing empty hotel row)
define('PENINSULAWORTH_HOTEL_ID', 128);    // NAYA -- Peninsula Worth Hotel Madinah (existing empty hotel row)
define('SHAZAREGENCY_HOTEL_ID', 171);      // NAYA -- Shaza Regency Plaza Madinah
define('MAYSANHARTHIA_HOTEL_ID', 98);      // NAYA -- Maysan Al Harthia Ex Frontel Alharthia Hotel Madinah (existing empty hotel row)
define('EMAARROYALMADINAH_HOTEL_ID', 102); // NAYA -- Emaar Royal Hotel Madinah (existing empty hotel row)
define('GRANDPLAZABADR_HOTEL_ID', 129);    // NAYA -- Grand Plaza Badr Al Maqam Hotel Madinah (existing empty hotel row)

// Four Points by Sheraton (155) aur Voco Hotel Makkah (156) ke liye koi
// handler register nahi karte -- inke paas abhi koi room data nahi hai,
// isliye NormalHotelHandler (default fallback) khud-ba-khud 'Coming Soon'
// page dikha dega.

require_once __DIR__ . '/base_handler.php';
require_once __DIR__ . '/normal_hotel.php';
require_once __DIR__ . '/marriot_jabal_omer.php';
require_once __DIR__ . '/movenpick_hajar_tower.php';
require_once __DIR__ . '/makkah_hotel.php';
require_once __DIR__ . '/makkah_towers.php';
require_once __DIR__ . '/fairmont_clocktower.php';
require_once __DIR__ . '/swissotel_makkah.php';
require_once __DIR__ . '/swissotel_almaqam.php';
require_once __DIR__ . '/al_marwa_rayhaan.php';
require_once __DIR__ . '/al_safwah_tower3.php';
require_once __DIR__ . '/conrad_makkah.php';
require_once __DIR__ . '/hilton_suites_makkah.php';      // NAYA
require_once __DIR__ . '/hilton_convention_makkah.php';
require_once __DIR__ . '/doubletree_hilton_makkah.php';  // NAYA
require_once __DIR__ . '/elaf_kinda_makkah.php';
require_once __DIR__ . '/sheraton_makkah.php';   // NAYA
require_once __DIR__ . '/m_hotel_makkah.php';
require_once __DIR__ . '/saja_hotel_makkah.php';
require_once __DIR__ . '/lemeridien_tower_makkah.php';  // bespoke
require_once __DIR__ . '/grand_al_massah.php';    // NAYA
require_once __DIR__ . '/royal_majestic.php';     // NAYA
require_once __DIR__ . '/maysan_al_mashaer.php';  // NAYA
require_once __DIR__ . '/maysan_al_maqam.php';    // NAYA
require_once __DIR__ . '/badr_al_massah.php';     // NAYA
require_once __DIR__ . '/ramada_al_fayzen.php';   // NAYA
require_once __DIR__ . '/emaar_grand.php';
require_once __DIR__ . '/snood_ajyad.php';         // NAYA
require_once __DIR__ . '/m_hotel_al_dana.php';     // NAYA (existing hotel id 69)
require_once __DIR__ . '/emaar_al_manar.php';      // NAYA (existing hotel id 83)
require_once __DIR__ . '/emaar_al_andalusia.php';  // NAYA (existing hotel id 84)
require_once __DIR__ . '/emaar_worth_elite.php';   // NAYA (existing hotel id 85)
require_once __DIR__ . '/emaar_al_khalil.php';     // NAYA (existing hotel id 86)
require_once __DIR__ . '/makarem_ajyad.php';       // NAYA (existing hotel id 67)
require_once __DIR__ . '/manzel_ajyad.php';        // NAYA (existing hotel id 70)
require_once __DIR__ . '/elaf_bakkah_qinwan.php';  // NAYA (existing hotel ids 71, 76)

// MADINAH HOTELS (naya batch)
require_once __DIR__ . '/jayden_hotel_madinah.php';                    // NAYA
require_once __DIR__ . '/dar_al_taqwa_madinah.php';                    // NAYA
require_once __DIR__ . '/dar_al_iman_intercontinental_madinah.php';    // NAYA
require_once __DIR__ . '/dar_al_hijra_intercontinental_madinah.php';   // NAYA
require_once __DIR__ . '/biltmore_madinah.php';                       // NAYA
require_once __DIR__ . '/makarem_burj_madinah.php';                   // NAYA
require_once __DIR__ . '/makarem_haram_view_suites_madinah.php';      // NAYA
require_once __DIR__ . '/elaf_taqwa_madinah.php';                     // NAYA
require_once __DIR__ . '/crown_plaza_ihg_madinah.php';                // NAYA
require_once __DIR__ . '/millenium_al_aqeeq_madinah.php';             // NAYA
require_once __DIR__ . '/millenium_al_taibah_madinah.php';            // NAYA
require_once __DIR__ . '/novotel_madinah.php';                        // NAYA
require_once __DIR__ . '/dar_al_eiman_al_haram_madinah.php';          // NAYA
require_once __DIR__ . '/peninsula_worth_madinah.php';                // NAYA
require_once __DIR__ . '/shaza_regency_plaza_madinah.php';            // NAYA
require_once __DIR__ . '/maysan_al_harthia_madinah.php';              // NAYA
require_once __DIR__ . '/emaar_royal_madinah.php';                    // NAYA
require_once __DIR__ . '/grand_plaza_badr_almaqam_madinah.php';       // NAYA

class HotelHandlerFactory {

    private static $handlers = [
        41 => 'MarriotJabalOmerHandler',
        43 => 'MakkahHotelHandler',
        44 => 'MakkahTowersHandler',
        63 => 'MovenpickHajarTowerHandler',
        145 => 'FairmontClockTowerHandler',
        146 => 'SwissotelMakkahHandler',
        147 => 'SwissotelAlMaqamHandler',
        148 => 'AlMarwaRayhaanHandler',
        149 => 'AlSafwahTower3Handler',
        150 => 'ConradMakkahHandler',
        151 => 'HiltonSuitesMakkahHandler',
        152 => 'HiltonConventionMakkahHandler',
        153 => 'DoubletreeHiltonMakkahHandler',
        154 => 'ElafKindaMakkahHandler',
        157 => 'SheratonMakkahHandler',
        158 => 'MHotelMakkahHandler',
        159 => 'SajaHotelMakkahHandler',
        160 => 'LeMeridienTowerMakkahHandler', // bespoke -- simpleHiddenMarkupHotels mein NAHI (apna khud ka block hai)
        161 => 'GrandAlMassahHandler',
        162 => 'RoyalMajesticHandler',
        163 => 'MaysanAlMashaerHandler',
        164 => 'MaysanAlMaqamHandler',
        165 => 'BadrAlMassahHandler',
        166 => 'RamadaAlFayzenHandler',
        167 => 'EmaarGrandHandler',
        168 => 'SnoodAjyadHandler',
        69 => 'MHotelAlDanaHandler',
        83 => 'EmaarAlManarHandler',
        84 => 'EmaarAlAndalusiaHandler',
        85 => 'EmaarWorthEliteHandler',
        86 => 'EmaarAlKhalilHandler',
        67 => 'MakaremAjyadHandler',
        70 => 'ManzelAjyadHandler',
        71 => 'ElafBakkahHandler',   // NAYA
        76 => 'ElafQinwanHandler',   // NAYA
        // 155 (Four Points), 156 (Voco) -- deliberately NOT registered,
        // falls back to NormalHotelHandler -> empty rooms -> Coming Soon UI

        // MADINAH HOTELS (naya batch)
        169 => 'JaydenHotelMadinahHandler',                  // NAYA
        94  => 'DarAlTaqwaMadinahHandler',                   // NAYA
        96  => 'DarAlImanIntercontinentalMadinahHandler',    // NAYA
        97  => 'DarAlHijraIntercontinentalMadinahHandler',   // NAYA
        93  => 'BiltmoreMadinahHandler',                     // NAYA
        106 => 'MakaremBurjMadinahHandler',                  // NAYA
        108 => 'MakaremHaramViewSuitesMadinahHandler',       // NAYA
        91  => 'ElafTaqwaMadinahHandler',                    // NAYA
        99  => 'CrownPlazaIhgMadinahHandler',              // NAYA
        101 => 'MilleniumAlAqeeqMadinahHandler',           // NAYA
        100 => 'MilleniumAlTaibahMadinahHandler',          // NAYA
        170 => 'NovotelMadinahHandler',                    // NAYA
        104 => 'DarAlEimanAlHaramMadinahHandler',          // NAYA
        128 => 'PeninsulaWorthMadinahHandler',              // NAYA
        171 => 'ShazaRegencyPlazaMadinahHandler',          // NAYA
        98  => 'MaysanAlHarthiaMadinahHandler',            // NAYA
        102 => 'EmaarRoyalMadinahHandler',                 // NAYA
        129 => 'GrandPlazaBadrAlMaqamMadinahHandler',      // NAYA
    ];

    // "Simple" hotels: room_type_code + is_weekend, 70 SAR hidden markup,
    // koi extra bed nahi, koi meal add-on nahi, koi supplement nahi.
    // (Elaf Bakkah/Qinwan bhi isi bucket mein hain -- extra bed/supplement
    // ke bina, sirf requires_meal_type=true unke handler class mein set
    // hai, jaisa Emaar Al Khalil (86) ke liye pehle se hai. Madinah ke
    // 4 naye hotels bhi isi bucket mein hain -- Dar Al Taqwa/Dar Al Iman
    // Intercontinental/Dar Al Hijra Intercontinental extra_bed use karte
    // hain jo unke apne handler class mein handle hota hai, aur Jayden
    // requires_meal_type=true use karta hai Standard/Indonesian rate
    // selector ke liye -- bilkul Emaar Al Khalil jaisa.)
    private static $simpleHiddenMarkupHotels = [145, 146, 147, 148, 154, 157, 158, 159, 161, 162, 163, 164, 165, 166, 167, 168, 69, 83, 84, 85, 86, 67, 70, 71, 76, 169, 94, 96, 97, 93, 106, 108, 91, 99, 101, 100, 170, 104, 128, 171, 98, 102, 129];

    // "Single-room + supplement" hotels: EK room type ('double'),
    // weekday/weekend, 70 SAR hidden markup on room, optional extra bed
    // (25 SAR hidden markup), optional flat supplements (no markup).
    // Naya aisa hotel add karne ke liye BAS is array mein ek line add
    // karo -- get_hotel_room_price.php, book_hotel_room.php ek hi
    // generic block se sabko handle karte hain, alag block likhne ki
    // zaroorat nahi.
    private static $singleRoomSupplementHotels = [149, 150, 151, 152, 153];

    public static function isSimpleHiddenMarkupHotel($hotel_id) {
        return in_array($hotel_id, self::$simpleHiddenMarkupHotels);
    }

    public static function isSingleRoomSupplementHotel($hotel_id) {
        return in_array($hotel_id, self::$singleRoomSupplementHotels);
    }

    public static function registerSimpleHiddenMarkupHotel($hotel_id) {
        if (!in_array($hotel_id, self::$simpleHiddenMarkupHotels)) {
            self::$simpleHiddenMarkupHotels[] = $hotel_id;
        }
    }

    public static function registerSingleRoomSupplementHotel($hotel_id) {
        if (!in_array($hotel_id, self::$singleRoomSupplementHotels)) {
            self::$singleRoomSupplementHotels[] = $hotel_id;
        }
    }

    public static function getHandler($hotel_id) {
        if (isset(self::$handlers[$hotel_id])) {
            $class = self::$handlers[$hotel_id];
            return new $class();
        }
        return new NormalHotelHandler();
    }

    public static function getHandlerClass($hotel_id) {
        return isset(self::$handlers[$hotel_id]) ? self::$handlers[$hotel_id] : 'NormalHotelHandler';
    }

    public static function hasCustomHandler($hotel_id) {
        return isset(self::$handlers[$hotel_id]);
    }

    public static function registerHandler($hotel_id, $handler_class) {
        self::$handlers[$hotel_id] = $handler_class;
    }
}
?>